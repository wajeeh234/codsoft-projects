import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:audioplayers/audioplayers.dart';

// Alarm model to hold time, tone, and status
class Alarm {
  TimeOfDay time;
  String tone;
  bool isActive;

  Alarm({required this.time, required this.tone, this.isActive = true});
}

// HomeScreen widget
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _currentTime = '';
  String _currentDate = '';
  List<Alarm> _alarms = [];
  Timer? _timer;
  final AudioPlayer _audioPlayer = AudioPlayer();
  Alarm? _ringingAlarm;

  @override
  void initState() {
    super.initState();
    _updateTime();
    _startClock();
  }

  void _startClock() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateTime();
      _checkAlarms();
    });
  }

  void _updateTime() {
    final now = DateTime.now();
    setState(() {
      _currentTime = DateFormat('hh:mm:ss a').format(now);
      _currentDate = DateFormat('EEEE, MMM d, yyyy').format(now);
    });
  }

  void _checkAlarms() {
    final now = TimeOfDay.now();
    for (var alarm in _alarms) {
      if (alarm.isActive &&
          now.hour == alarm.time.hour &&
          now.minute == alarm.time.minute) {
        _ringingAlarm = alarm;
        _playAlarm(alarm.tone);
        _showAlarmDialog();
        break;
      }
    }
  }

  Future<void> _playAlarm(String tone) async {
    String alarmPath = 'assets/sounds/alarem5.mp3'; // Default tone

    // Select the tone based on user choice
    switch (tone) {
      case 'Tone 1':
        alarmPath = 'assets/sounds/alarem6.mp3';
        break;
      case 'Tone 2':
        alarmPath = 'assets/sounds/alarem7.mp3';
        break;
      case 'Tone 3':
        alarmPath = 'assets/sounds/alarem8.mp3';
        break;
    }

    try {
      await _audioPlayer.setSource(AssetSource(alarmPath));
      await _audioPlayer.resume();
    } catch (e) {
      print('Error playing alarm: $e');
    }
  }

  void _showAlarmDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Alarm Ringing'),
        content: const Text('What would you like to do?'),
        actions: [
          TextButton.icon(
            onPressed: _snoozeAlarm,
            icon: const Icon(Icons.snooze),
            label: const Text('Snooze (5 mins)'),
          ),
          TextButton.icon(
            onPressed: _dismissAlarm,
            icon: const Icon(Icons.alarm_off),
            label: const Text('Dismiss'),
          ),
        ],
      ),
    );
  }

  void _snoozeAlarm() {
    if (_ringingAlarm != null) {
      final snoozeTime = _ringingAlarm!.time.replacing(
        minute: (_ringingAlarm!.time.minute + 5) % 60,
        hour: _ringingAlarm!.time.minute >= 55
            ? (_ringingAlarm!.time.hour + 1) % 24
            : _ringingAlarm!.time.hour,
      );
      setState(() {
        _ringingAlarm!.time = snoozeTime;
      });
    }
    _audioPlayer.stop();
    Navigator.pop(context);
  }

  void _dismissAlarm() {
    _audioPlayer.stop();
    Navigator.pop(context);
  }

  Future<void> _setAlarm() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (pickedTime != null) {
      String selectedTone = 'Default Tone';

      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text('Choose Alarm Tone'),
          content: DropdownButton<String>(
            value: selectedTone,
            onChanged: (String? newValue) {
              setState(() {
                selectedTone = newValue!;
              });
            },
            items: <String>['Default Tone', 'Tone 1', 'Tone 2', 'Tone 3']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  _alarms.add(Alarm(time: pickedTime, tone: selectedTone));
                });
                Navigator.pop(context);
              },
              child: const Text('Set Alarm'),
            ),
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alarm Clock'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _currentTime,
              style: const TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                fontFamily: 'Digital',
                shadows: [
                  Shadow(
                    blurRadius: 4.0,
                    color: Colors.blue,
                    offset: Offset(2.0, 2.0),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _currentDate,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              onPressed: _setAlarm,
              icon: const Icon(Icons.alarm),
              label: const Text('Set New Alarm'),
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                backgroundColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _alarms.length,
                itemBuilder: (context, index) {
                  final alarm = _alarms[index];
                  return Card(
                    margin:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    child: ListTile(
                      leading: const Icon(Icons.access_alarm,
                          color: Colors.blueAccent),
                      title: Text(
                        'Alarm at ${alarm.time.format(context)} (${alarm.tone})',
                        style: const TextStyle(fontSize: 18),
                      ),
                      trailing: Switch(
                        value: alarm.isActive,
                        onChanged: (bool value) {
                          setState(() {
                            alarm.isActive = value;
                          });
                        },
                      ),
                      onLongPress: () {
                        setState(() {
                          _alarms.removeAt(index);
                        });
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
