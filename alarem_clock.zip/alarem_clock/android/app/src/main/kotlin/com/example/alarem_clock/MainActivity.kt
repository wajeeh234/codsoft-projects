package com.example.alarem_clock

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
