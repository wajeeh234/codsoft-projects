import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class QuizScreen extends StatefulWidget {
  final String quizTitle;

  QuizScreen({required this.quizTitle});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  List<bool> _isCorrect = [];

  final Map<String, List<Map<String, Object>>> _quizData = {
    'General Knowledge': [
      {
        'questionText': 'Who was the first President of the United States?',
        'answers': [
          'George Washington',
          'Thomas Jefferson',
          'Abraham Lincoln',
          'John Adams'
        ],
        'correctAnswer': 'George Washington'
      },
      {
        'questionText': 'Which planet is known as the Red Planet?',
        'answers': ['Mars', 'Venus', 'Jupiter', 'Saturn'],
        'correctAnswer': 'Mars'
      },
      {
        'questionText': 'Which is the smallest continent by land area?',
        'answers': ['Australia', 'Europe', 'Antarctica', 'South America'],
        'correctAnswer': 'Australia'
      },
      {
        'questionText': 'What is the capital of France?',
        'answers': ['Berlin', 'Paris', 'Madrid', 'Rome'],
        'correctAnswer': 'Paris'
      },
      {
        'questionText': 'What year did the Titanic sink?',
        'answers': ['1902', '1912', '1922', '1932'],
        'correctAnswer': '1912'
      },
    ],
    'Math Quiz': [
      {
        'questionText': 'What is 7 + 8?',
        'answers': ['14', '15', '16', '17'],
        'correctAnswer': '15'
      },
      {
        'questionText': 'What is the square root of 64?',
        'answers': ['6', '7', '8', '9'],
        'correctAnswer': '8'
      },
      {
        'questionText': 'Solve for x: 2x + 3 = 11.',
        'answers': ['2', '3', '4', '5'],
        'correctAnswer': '4'
      },
      {
        'questionText': 'What is 12 x 12?',
        'answers': ['120', '132', '144', '156'],
        'correctAnswer': '144'
      },
      {
        'questionText':
            'What is the value of Pi (π) rounded to two decimal places?',
        'answers': ['3.12', '3.14', '3.16', '3.18'],
        'correctAnswer': '3.14'
      },
    ],
    'Science Quiz': [
      {
        'questionText': 'What is the chemical symbol for water?',
        'answers': ['H2O', 'O2', 'CO2', 'NaCl'],
        'correctAnswer': 'H2O'
      },
      {
        'questionText': 'What planet is known as the Red Planet?',
        'answers': ['Mars', 'Jupiter', 'Saturn', 'Venus'],
        'correctAnswer': 'Mars'
      },
      {
        'questionText': 'What gas do plants need to perform photosynthesis?',
        'answers': ['Oxygen', 'Hydrogen', 'Carbon Dioxide', 'Nitrogen'],
        'correctAnswer': 'Carbon Dioxide'
      },
      {
        'questionText': 'What is the powerhouse of the cell?',
        'answers': [
          'Nucleus',
          'Mitochondria',
          'Ribosome',
          'Endoplasmic Reticulum'
        ],
        'correctAnswer': 'Mitochondria'
      },
      {
        'questionText': 'What is the basic unit of life?',
        'answers': ['Atom', 'Cell', 'Molecule', 'Organ'],
        'correctAnswer': 'Cell'
      },
    ],
    // Add more quiz categories if needed...
  };

  late List<Map<String, Object>> _questions;

  @override
  void initState() {
    super.initState();
    _questions = _quizData[widget.quizTitle] ?? [];
  }

  void _answerQuestion(String selectedAnswer) {
    String correctAnswer =
        _questions[_currentQuestionIndex]['correctAnswer'] as String;

    if (selectedAnswer == correctAnswer) {
      _score++;
      _isCorrect.add(true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Correct!', style: TextStyle(color: Colors.green))),
      );
    } else {
      _isCorrect.add(false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Incorrect!', style: TextStyle(color: Colors.red))),
      );
    }

    setState(() {
      if (_currentQuestionIndex < _questions.length - 1) {
        _currentQuestionIndex++;
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => ResultScreen(
              score: _score,
              totalQuestions: _questions.length,
              isCorrect: _isCorrect,
              questions: _questions,
            ),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.quizTitle),
          centerTitle: true,
        ),
        body: Center(
          child: Text('No questions available for this quiz.'),
        ),
      );
    }

    var currentQuestion = _questions[_currentQuestionIndex];
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.quizTitle),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(
              value: (_currentQuestionIndex + 1) / _questions.length,
              backgroundColor: Colors.grey[300],
              color: Colors.teal,
            ),
            SizedBox(height: 20),
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  currentQuestion['questionText'] as String,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            SizedBox(height: 20),
            ...(currentQuestion['answers'] as List<String>).map((answer) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: ElevatedButton(
                  onPressed: () => _answerQuestion(answer),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 16.0),
                    backgroundColor: Colors.teal, // Button color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    answer,
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final int totalQuestions;
  final List<bool> isCorrect;
  final List<Map<String, Object>> questions;

  ResultScreen({
    required this.score,
    required this.totalQuestions,
    required this.isCorrect,
    required this.questions,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz Results'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade50, Colors.teal.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'You scored $score out of $totalQuestions!',
              style: GoogleFonts.openSans(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.teal[800],
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: questions.length,
                itemBuilder: (ctx, index) {
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8.0),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(16.0),
                      leading: Icon(
                        isCorrect[index] ? Icons.check_circle : Icons.error,
                        color: isCorrect[index] ? Colors.green : Colors.red,
                      ),
                      title: Text(
                        questions[index]['questionText'] as String,
                        style: GoogleFonts.openSans(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      subtitle: Text(
                        isCorrect[index]
                            ? 'Correct: ${(questions[index]['correctAnswer'] as String)}'
                            : 'Incorrect. Correct Answer: ${(questions[index]['correctAnswer'] as String)}',
                        style: GoogleFonts.openSans(
                          fontSize: 16,
                          color: isCorrect[index] ? Colors.green : Colors.red,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                backgroundColor: Colors.teal,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Back to Home',
                style: GoogleFonts.openSans(
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
