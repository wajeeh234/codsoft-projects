import 'package:flutter/material.dart';

class NewQuizScreen extends StatefulWidget {
  @override
  _NewQuizScreenState createState() => _NewQuizScreenState();
}

class _NewQuizScreenState extends State<NewQuizScreen> {
  final _formKey = GlobalKey<FormState>();
  String _quizTitle = '';
  List<Map<String, Object>> _questions = [];
  String _questionText = '';
  List<String> _answers = [];
  String _correctAnswer = '';

  void _addQuestion() {
    if (_questionText.isNotEmpty &&
        _answers.length >= 2 &&
        _correctAnswer.isNotEmpty) {
      setState(() {
        _questions.add({
          'questionText': _questionText,
          'answers': _answers,
          'correctAnswer': _correctAnswer,
        });
        _questionText = '';
        _answers = [];
        _correctAnswer = '';
      });
    }
  }

  void _saveQuiz() {
    if (_formKey.currentState!.validate()) {
      // Save the quiz data and navigate back to the home screen
      Navigator.of(context).pop({
        'quizTitle': _quizTitle,
        'questions': _questions,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create a New Quiz'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Quiz Title'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a quiz title';
                  }
                  return null;
                },
                onChanged: (value) {
                  setState(() {
                    _quizTitle = value;
                  });
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                decoration: InputDecoration(labelText: 'Question'),
                onChanged: (value) {
                  setState(() {
                    _questionText = value;
                  });
                },
              ),
              SizedBox(height: 10),
              Column(
                children: List.generate(
                  4, // Assuming 4 options for each question
                  (index) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: TextFormField(
                      decoration:
                          InputDecoration(labelText: 'Answer ${index + 1}'),
                      onChanged: (value) {
                        if (_answers.length > index) {
                          _answers[index] = value;
                        } else {
                          _answers.add(value);
                        }
                      },
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                decoration: InputDecoration(labelText: 'Correct Answer'),
                onChanged: (value) {
                  setState(() {
                    _correctAnswer = value;
                  });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _addQuestion,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                ),
                child: Text('Add Question'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveQuiz,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                ),
                child: Text('Save Quiz'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
