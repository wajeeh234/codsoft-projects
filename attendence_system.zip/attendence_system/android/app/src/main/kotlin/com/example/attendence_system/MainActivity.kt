package com.example.attendence_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
