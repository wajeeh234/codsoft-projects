import 'package:attendance_system/screens/auth/login_screen.dart';
// ignore: unused_import
import 'package:attendance_system/screens/auth/student_login_page.dart';
import 'package:attendance_system/splash_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Portal',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => SplashScreen(),
        '/login': (context) => LoginPage(),
        '/studentFeatures': (context) => StudentFeaturePage(
              courses: [
                'Mathematics',
                'Physics',
                'Data Science'
              ], // example courses
              onCourseSelected: (course) {
                print('Course selected: $course');
              },
              onCoursesUpdated: (List<String> updatedCourses) {},
            ),
        '/attendance': (context) => AttendancePage(),
      },
    );
  }
}

AttendancePage() {}

StudentFeaturePage(
    {required List<String> courses,
    required Null Function(dynamic course) onCourseSelected,
    required Null Function(List<String> updatedCourses) onCoursesUpdated}) {}
