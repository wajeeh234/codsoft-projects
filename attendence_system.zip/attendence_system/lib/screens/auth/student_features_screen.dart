import 'package:flutter/material.dart';

class StudentFeaturePage extends StatefulWidget {
  final List<String> courses;
  final Function(List<String>) onCoursesUpdated;
  final Function(String) onCourseSelected;

  const StudentFeaturePage({
    Key? key,
    required this.courses,
    required this.onCoursesUpdated,
    required this.onCourseSelected,
  }) : super(key: key);

  @override
  _StudentFeaturePageState createState() => _StudentFeaturePageState();
}

class _StudentFeaturePageState extends State<StudentFeaturePage> {
  List<String> courses = [];

  @override
  void initState() {
    super.initState();
    courses =
        widget.courses; // Initialize with the courses passed in constructor
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Course Management'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 5,
                    child: ListTile(
                      title: Text(
                        courses[index],
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: const Text('Attendance: 85%'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          setState(() {
                            courses.removeAt(index);
                          });
                          widget.onCoursesUpdated(courses);
                        },
                      ),
                      onTap: () {
                        widget.onCourseSelected(courses[index]);
                      },
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add New Course'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                _addNewCourseDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _addNewCourseDialog(BuildContext context) {
    TextEditingController courseController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Course'),
          content: TextField(
            controller: courseController,
            decoration: const InputDecoration(
              labelText: 'Course Name',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: const Text('Add'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromARGB(199, 236, 233, 11)),
              onPressed: () {
                setState(() {
                  courses.add(courseController.text);
                });
                widget.onCoursesUpdated(courses);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
