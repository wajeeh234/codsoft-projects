import 'package:flutter/material.dart';

class StudentLoginPage extends StatefulWidget {
  const StudentLoginPage({super.key});

  @override
  _StudentLoginPageState createState() => _StudentLoginPageState();
}

class _StudentLoginPageState extends State<StudentLoginPage> {
  final TextEditingController _studentIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // App Logo or Icon
            const CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage(
                  'assets/images/student3.png'), // Ensure logo is added to assets
            ),
            const SizedBox(height: 30),
            const Text(
              'Student Login',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.orangeAccent,
              ),
            ),
            const SizedBox(height: 40),
            // Student ID Field
            TextField(
              controller: _studentIdController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Student ID',
                prefixIcon: Icon(Icons.person),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            // Password Field
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Password',
                prefixIcon: Icon(Icons.lock),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 30),
            // Login Button or Loading Indicator
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: () {
                      _handleLogin(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 50, vertical: 15),
                      textStyle: const TextStyle(fontSize: 18),
                    ),
                    child: const Text('Login'),
                  ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () {
                // Navigate to password recovery
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.grey,
              ),
              child: const Text('Forgot Password?'),
            ),
          ],
        ),
      ),
    );
  }

  void _handleLogin(BuildContext context) {
    String studentId = _studentIdController.text;
    String password = _passwordController.text;

    if (studentId.isNotEmpty && password.isNotEmpty) {
      setState(() {
        _isLoading = true;
      });

      // Simulate a login process (you can replace this with actual login logic)
      Future.delayed(const Duration(seconds: 3), () {
        setState(() {
          _isLoading = false;
        });

        // Navigate to Student Features Screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => StudentFeaturePage(
              onCoursesUpdated: (List<String> updatedCourses) {
                // Handle the updated courses list
                print('Courses updated: $updatedCourses');
              },
              onCourseSelected: (String) {},
              courses: [],
            ),
          ),
        );
      });
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Login Failed'),
          content: const Text('Please fill in all fields'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }
}

class StudentFeaturePage extends StatefulWidget {
  final List<String> courses;
  final Function(List<String>) onCoursesUpdated;
  final Function(String) onCourseSelected;

  const StudentFeaturePage({
    required this.courses,
    required this.onCoursesUpdated,
    required this.onCourseSelected,
    Key? key,
  }) : super(key: key);

  @override
  _StudentFeaturePageState createState() => _StudentFeaturePageState();
}

class _StudentFeaturePageState extends State<StudentFeaturePage> {
  List<String> courses = [];

  @override
  void initState() {
    super.initState();
    courses = widget.courses;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Student Course Management',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurpleAccent,
        centerTitle: true,
        elevation: 5.0,
        shadowColor: Colors.deepPurple.withOpacity(0.5),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Your Courses',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                color: Colors.deepPurple,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 8,
                    shadowColor: Colors.deepPurpleAccent.withOpacity(0.4),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 15),
                      title: Text(
                        courses[index],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Colors.deepPurple,
                        ),
                      ),
                      subtitle: const Text(
                        'Attendance: 85%',
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        color: Colors.red,
                        onPressed: () {
                          setState(() {
                            courses.removeAt(index);
                          });
                          widget.onCoursesUpdated(courses);
                        },
                      ),
                      onTap: () {
                        widget.onCourseSelected(courses[index]);
                      },
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text(
                'Add New Course',
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurpleAccent,
                padding:
                    const EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                elevation: 8,
                shadowColor: Colors.deepPurpleAccent.withOpacity(0.4),
              ),
              onPressed: () {
                _addNewCourseDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _addNewCourseDialog(BuildContext context) {
    TextEditingController courseController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: const Text('Add New Course'),
          content: TextField(
            controller: courseController,
            decoration: InputDecoration(
              labelText: 'Course Name',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.redAccent,
              ),
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurpleAccent,
              ),
              child: const Text('Add'),
              onPressed: () {
                setState(() {
                  courses.add(courseController.text);
                });
                widget.onCoursesUpdated(courses);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
