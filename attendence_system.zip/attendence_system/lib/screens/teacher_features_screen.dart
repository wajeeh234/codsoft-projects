import 'package:flutter/material.dart';

class Course {
  String name;
  String teacherName;
  List<Student> students;

  Course(
      {required this.name, required this.teacherName, required this.students});

  bool? get isSelected => null;
}

class Student {
  String name;
  bool isPresent;

  Student({required this.name, this.isPresent = false});
}

class TeacherFeaturePage extends StatefulWidget {
  final List<Course> courses;

  TeacherFeaturePage({Key? key, required this.courses}) : super(key: key);

  @override
  _TeacherFeaturePageState createState() => _TeacherFeaturePageState();
}

class _TeacherFeaturePageState extends State<TeacherFeaturePage> {
  void _addCourse(Course course) {
    setState(() {
      widget.courses.add(course);
    });
  }

  void _removeCourse(int index) {
    setState(() {
      widget.courses.removeAt(index);
    });
  }

  void _addStudentToCourse(int courseIndex, Student student) {
    setState(() {
      widget.courses[courseIndex].students.add(student);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Features'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            FeatureCard(
              icon: Icons.book,
              title: 'Manage Courses',
              description: 'View and manage courses for students.',
              color: Colors.deepPurple,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ManageCoursesPage(
                      courses: widget.courses,
                      addCourse: _addCourse,
                      removeCourse: _removeCourse,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            FeatureCard(
              icon: Icons.check_circle_outline,
              title: 'Manage Attendance',
              description: 'Record and view student attendance.',
              color: Colors.teal,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ManageAttendancePage(courses: widget.courses),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            FeatureCard(
              icon: Icons.class_,
              title: 'Manage Students',
              description: 'View and manage student information.',
              color: Colors.orange,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ManageStudentsPage(
                      courses: widget.courses,
                      addStudentToCourse: _addStudentToCourse,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ManageCoursesPage extends StatelessWidget {
  final List<Course> courses;
  final Function(Course) addCourse;
  final Function(int) removeCourse;

  const ManageCoursesPage({
    Key? key,
    required this.courses,
    required this.addCourse,
    required this.removeCourse,
  }) : super(key: key);

  void _showAddCourseDialog(BuildContext context) {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController teacherController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Course'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Course Name'),
            ),
            TextField(
              controller: teacherController,
              decoration: const InputDecoration(labelText: 'Teacher Name'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final newCourse = Course(
                name: nameController.text,
                teacherName: teacherController.text,
                students: [],
              );
              addCourse(newCourse);
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Courses'),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView.builder(
        itemCount: courses.length,
        itemBuilder: (context, index) {
          final course = courses[index];
          return ListTile(
            title: Text(course.name),
            subtitle: Text('Instructor: ${course.teacherName}'),
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () {
                removeCourse(index);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddCourseDialog(context),
        backgroundColor: Colors.deepPurple,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class ManageAttendancePage extends StatelessWidget {
  final List<Course> courses;

  const ManageAttendancePage({Key? key, required this.courses})
      : super(key: key);

  void _showStudentAttendanceDialog(BuildContext context, Course course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Manage Attendance for ${course.name}'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: course.students.length,
            itemBuilder: (context, index) {
              final student = course.students[index];
              return CheckboxListTile(
                title: Text(student.name),
                value: student.isPresent,
                onChanged: (bool? value) {
                  student.isPresent = value ?? false;
                  (context as Element).markNeedsBuild(); // Trigger a rebuild
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Attendance'),
        backgroundColor: Colors.teal,
      ),
      body: ListView.builder(
        itemCount: courses.length,
        itemBuilder: (context, index) {
          final course = courses[index];
          return ListTile(
            title: Text(course.name),
            subtitle: Text('Instructor: ${course.teacherName}'),
            trailing: IconButton(
              icon: const Icon(Icons.check_circle, color: Colors.green),
              onPressed: () {
                _showStudentAttendanceDialog(context, course);
              },
            ),
          );
        },
      ),
    );
  }
}

class ManageStudentsPage extends StatelessWidget {
  final List<Course> courses;
  final Function(int, Student) addStudentToCourse;

  const ManageStudentsPage({
    Key? key,
    required this.courses,
    required this.addStudentToCourse,
  }) : super(key: key);

  void _showAddStudentDialog(BuildContext context, int courseIndex) {
    final TextEditingController nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Student'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(labelText: 'Student Name'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final newStudent = Student(name: nameController.text);
              addStudentToCourse(courseIndex, newStudent);
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Students'),
        backgroundColor: Colors.orange,
      ),
      body: ListView.builder(
        itemCount: courses.length,
        itemBuilder: (context, index) {
          final course = courses[index];
          return ListTile(
            title: Text(course.name),
            subtitle: Text('Instructor: ${course.teacherName}'),
            trailing: IconButton(
              icon: const Icon(Icons.person_add, color: Colors.blue),
              onPressed: () {
                _showAddStudentDialog(context, index);
              },
            ),
          );
        },
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color color;
  final VoidCallback onTap;

  const FeatureCard({
    Key? key,
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Card(
        elevation: 8,
        color: color.withOpacity(0.2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Icon(icon, color: color, size: 40),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      description,
                      style: TextStyle(
                          fontSize: 14, color: color.withOpacity(0.8)),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
